from Sol import Sol

for x in range(1,20):
    s=Sol(x)
    if(s.Solve()):
        print(x)
        print(s)
    else:
        print("No solution found for ",x,"\n")
