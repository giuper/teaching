from Sol import Sol

instances=[
    [[2,3],[1,2],8],\
    [[2,3],[1,2],5],\
    [[2,3],[1,2],4],\
    [[2,3,5],[1,1,2],17],\
    [[2,3,5],[1,1,3],17],\
    [[2,3,5],[1,1,3],12],\
    [[2,3,5],[1,1,3],11],\
]


for inst in instances:
    [L,M,t]=inst
    S=Solve(L,M,t)
    print("L=",L,"M=",M,"\t",t,"\t",S.Solve())





