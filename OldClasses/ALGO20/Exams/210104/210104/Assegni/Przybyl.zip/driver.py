from Sol import Sol


L=[3,7,6,19,2]
T=[9,13,5]

print(L)

for t in T:
    s=Sol(L,t)
    print(t,"\t",s.Solve())





