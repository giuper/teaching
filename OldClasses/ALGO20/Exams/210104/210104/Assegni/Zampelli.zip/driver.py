from Sol import contaDisp


for k in range(2,20):
    print(k,"\t",contaDisp(100000,k))

